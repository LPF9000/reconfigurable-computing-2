Lab 1

Group Members: 
Ryan Laur
Benjamin Wheeler

No problems reported. 