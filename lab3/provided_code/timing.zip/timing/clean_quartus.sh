#!/usr/bin/bash

rm -rf output_files
rm -rf incremental_db
rm -rf db
rm -rf *.qws
